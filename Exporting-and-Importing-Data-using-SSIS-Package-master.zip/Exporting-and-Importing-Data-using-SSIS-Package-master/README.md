# Exporting-and-Importing-Data-using-SSIS-Package
This repository houses the SSIS packages used to export and import data from SQL Server using .txt flat file

DWBI Assignment II.doc - This document houses the step by step process involved in exporting and importing data in SQL Server using SQL Server Integration Services (SSIS) package

EmpData.dtsx - The EmpData SSIS package is used to export the data from SQL Server into a .txt file

FFCM_SQL.dtsx - The FFCM_SQL SSIS package is used to import the data from the .txt file into SQL Server

StagingTable.sql - This query is used to create the required staging table to store the data
